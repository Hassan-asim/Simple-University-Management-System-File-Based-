import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import javax.swing.*;
public class FP {
	public static String[] save_array() {
		File rec = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\Record.txt");
		long Index = rec.length();
		String[] array = new String[(int) Index];
		try {
			BufferedReader file = new BufferedReader(new FileReader("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\Record.txt"));
			String line;
			int i = 0;
			while ((line = file.readLine()) != null && line !="") {
				array[i] = line;
				i++;
			}
			file.close();
		} catch (Exception e) {
			System.out.println("Problem reading file.");
		}
		return array;
		
		
		

	}
		
	private static void NameKeyTyped(java.awt.event.KeyEvent evt) {
		char a = evt.getKeyChar();
		if(!Character.isAlphabetic(a)) {
			evt.consume();
		}
	}
	
	private static void degreeKeyTyped(java.awt.event.KeyEvent evt) {
		char a = evt.getKeyChar();
		if(!Character.isAlphabetic(a)) {
			evt.consume();
		}
	}
		
		private static void cnicKeyTyped(java.awt.event.KeyEvent evt) {
			char a = evt.getKeyChar();
			if(a == '-') {
				
			}
			else if( !Character.isDigit(a) ) {
				evt.consume();
			}
		}
			
			private static void phoneKeyTyped(java.awt.event.KeyEvent evt) {
				char a = evt.getKeyChar();
				if(a == '-') {
					
				}
				else if(!Character.isDigit(a)) {
					evt.consume();
					}
			}
	 public static void main(String[] arg) {
		 	ImageIcon invalidimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\invalid.jpg");
		 	ImageIcon loginchangeimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\loginCHANGE.jpg");
	        ImageIcon iconimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\icon.png");
	        ImageIcon iconbgimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\iconbg.png");
	        ImageIcon iconname = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\logoname.png");
	        ImageIcon loginimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\login.jpg");
	        ImageIcon welcomeimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\2.jpg");
	        ImageIcon enrollimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\4.png");
	        ImageIcon enrollbg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\enrollbg.png");
	        ImageIcon searchimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\search.png");
	        ImageIcon updateimg = new ImageIcon("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\src\\update.png");
	        
	        
	        JFrame screen = new JFrame("OXFORD UNIVERSITY");
	        screen.setIconImage(iconimg.getImage());
	        screen.setSize(900, 600);
	        screen.setResizable(false);
	        screen.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	        screen.setLayout(null);
	        

	        JTextField email = new JTextField();
			email.setBounds(295, 215, 310, 40);
			email.setOpaque(false);
			email.setForeground(Color.LIGHT_GRAY);
			screen.add(email);
			
			JTextField password = new JTextField();
			password.setBounds(295, 300, 310, 40);
			password.setOpaque(false);
			password.setForeground(Color.LIGHT_GRAY);
			screen.add(password);

	        

	        JButton b2 = new JButton("LOG-IN");
	        b2.setBounds(525, 350, 100, 30);
	        b2.setBorderPainted(false);
	        b2.setContentAreaFilled(false);
	        b2.setFocusPainted(false);
	        b2.setForeground(Color.CYAN);
	        b2.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 15));
	        screen.add(b2);
	        
	        JButton b3 = new JButton("Change LOGIN Details");
	        b3.setBounds(270, 350, 160, 30);
	        b3.setBorderPainted(false);
	        b3.setContentAreaFilled(false);
	        b3.setFocusPainted(false);
	        b3.setForeground(Color.CYAN);
	        b3.setFont(new Font("Bahnschrift Light SemiCondensed", Font.CENTER_BASELINE, 10));
	        screen.add(b3);

	        JLabel logoname = new JLabel();
		    logoname = new JLabel("", iconname, JLabel.CENTER);
		    logoname.setBounds(0, 10, 300, 100);
		    screen.add(logoname);
	        
	        JLabel bg = new JLabel();
	        bg = new JLabel("", loginimg, JLabel.CENTER);
	        bg.setBounds(0, 0, 900, 600);
	        screen.add(bg);

	        screen.setVisible(true);
	       
	        b2.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	try {
						File rec0 = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\login.txt");
						
						
						FileReader read = new FileReader(rec0);
						BufferedReader BFR = new BufferedReader(read);
						
						String line1 = BFR.readLine();
						String line2 = BFR.readLine();
						
						
						String emailch1 = email.getText();
		            	String passwordch1 = password.getText();
		            	
		            	
		            	if (line1.equals(emailch1) && line2.equals(passwordch1) ) {
		            		screen.setVisible(false);
			            	JFrame screen2 = new JFrame("OXFORD UNIVERSITY");
			            	screen2.setSize(1000, 600);
			    	        screen2.setResizable(false);
			    	        screen2.setIconImage(iconimg.getImage());
			    	        screen2.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	        screen2.setLayout(null);
			    	        
			    	        
			    	        
			    	        
			    	        
			    	        
			    	        JButton b1 = new JButton("ENROLL");
			    	        b1.setBounds(350, 200, 300, 50);
			    	        b1.setBorder(new RoundedBorder(50));
			    	        b1.setForeground(Color.CYAN);
			    	        b1.setContentAreaFilled(false);
		    		        b1.setFocusPainted(false);
			    	        b1.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 15));
			    	        screen2.add(b1);
			    	        
			    	        
			    	        JButton b11 = new JButton("UPDATE");
			    	        b11.setBounds(350, 300, 300, 50);
			    	        b11.setBorder(new RoundedBorder(50));
			    	        b11.setForeground(Color.CYAN);
			    	        b11.setContentAreaFilled(false);
		    		        b11.setFocusPainted(false);
			    	        b11.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 15));
			    	        screen2.add(b11);
			    	        
			    	        
			    	        JButton b111 = new JButton("SEARCH");
			    	        b111.setBounds(350, 400, 300, 50);
			    	        b111.setBorder(new RoundedBorder(50));
			    	        b111.setForeground(Color.CYAN);
			    	        b111.setContentAreaFilled(false);
		    		        b111.setFocusPainted(false);
			    	        b111.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 15));
			    	        screen2.add(b111);
			    	        
			    	        JLabel logo = new JLabel();
		    		        logo = new JLabel("", iconimg, JLabel.CENTER);
		    		        logo.setBounds(25, 35, 200, 200);
		    		        screen2.add(logo);
		    		        
		    		        JLabel logobg = new JLabel();
		    		        logobg = new JLabel("", iconbgimg, JLabel.CENTER);
		    		        logobg.setBounds(0, 0, 250, 250);
		    		        screen2.add(logobg);
			    	        
		    		        JLabel logoname = new JLabel();
		    		        logoname = new JLabel("", iconname, JLabel.CENTER);
		    		        logoname.setBounds(180, 15, 400, 150);
		    		        screen2.add(logoname);
		    		        
		    		        JLabel quot = new JLabel("\"THE BEST");
		    		        JLabel quot1 = new JLabel("WAY TO");
		    		        JLabel quot2 = new JLabel("PRIDICT THE");
		    		        JLabel quot3 = new JLabel("FUTURE IS TO");
		    		        JLabel quot4 = new JLabel("CHANGE IT\"");
		    		        quot.setBounds(40, 150, 250, 250);
		    		        quot1.setBounds(40, 180, 250, 250);
		    		        quot2.setBounds(40, 210, 250, 250);
		    		        quot3.setBounds(40, 240, 250, 250);
		    		        quot4.setBounds(40, 270, 250, 250);
		    		        quot.setForeground(Color.WHITE);
		    		        quot1.setForeground(Color.CYAN);
		    		        quot2.setForeground(Color.WHITE);
		    		        quot3.setForeground(Color.CYAN);
		    		        quot4.setForeground(Color.WHITE);
		    		        quot.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 30));
		    		        quot1.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 30));
		    		        quot2.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 30));
		    		        quot3.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 30));
		    		        quot4.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 30));
		    		        screen2.add(quot);
		    		        screen2.add(quot1);
		    		        screen2.add(quot2);
		    		        screen2.add(quot3);
		    		        screen2.add(quot4);
		    		        
		    		        
			    	        b1.addActionListener(new ActionListener() {
			    	            public void actionPerformed(ActionEvent e) {
			    	            	screen2.setVisible(false);
			    	            	
			    	            	JFrame screen1 = new JFrame("OXFORD UNIVERSITY");
			    	            	screen1.setSize(1000, 600);
			    	    	        screen1.setResizable(false);
			    	    	        screen1.setIconImage(iconimg.getImage());
			    	    	        screen1.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	    	        screen1.setLayout(null);
			    	    	        
			    	    	        JButton back = new JButton(" Go Back");
				    		        back.setBounds(20, 510, 200, 40);
				    		        back.setBorder(new RoundedBorder(50));
				    		        back.setContentAreaFilled(false);
				    		        back.setFocusPainted(false);
				    		        back.setForeground(Color.WHITE);
				    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
			        		        screen1.add(back);
			    	    	        
			        		        JLabel title = new JLabel("REGISTRATION", SwingConstants.CENTER);
			        		        title.setBounds(600, 100, 200, 40);
			        		        title.setForeground(Color.WHITE);
			        		        title.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN, 20));
			        		        screen1.add(title);
			    	    	        
			    	    	        JTextField Registration_no = new JTextField();
			    	    	        Registration_no.setBounds(650, 190, 250, 25);
			    	    	        Registration_no.setBackground(Color.white);
			    	    			screen1.add(Registration_no);
			    	    			
			    	    			JTextField Name = new JTextField();
			    	    	        Name.setBounds(650, 220, 250, 25);
			    	    	        Name.setBackground(Color.white);
			    	    			screen1.add(Name);
			    	    			
			    	    			Name.addKeyListener(new java.awt.event.KeyAdapter() {
			    	    				public void keyTyped(java.awt.event.KeyEvent evt) {
			    	    					NameKeyTyped(evt);
			    	    				}
			    	    			});
			    	    			
			    	    			
			    	    			
			    	    			JTextField Program = new JTextField();
			    	    	        Program.setBounds(650, 250, 250, 25);
			    	    	        Program.setBackground(Color.white);
			    	    			screen1.add(Program);
			    	    			Program.addKeyListener(new java.awt.event.KeyAdapter() {
			    	    				public void keyTyped(java.awt.event.KeyEvent evt) {
			    	    					degreeKeyTyped(evt);
			    	    				}
			    	    			});
			    	    			
			    	    			JTextField CNIC1 = new JTextField();
			    	    			CNIC1.setBounds(650, 280, 250, 25);
			    	    			CNIC1.setBackground(Color.white);
			    	    			screen1.add(CNIC1);
			    	    			CNIC1.addKeyListener(new java.awt.event.KeyAdapter() {
			    	    				public void keyTyped(java.awt.event.KeyEvent evt) {
			    	    					cnicKeyTyped(evt);
			    	    				}
			    	    			});
			    	    			
			    	    			JTextField email = new JTextField();
			    	    			email.setBounds(650, 310, 250, 25);
			    	    			email.setBackground(Color.white);
			    	    			screen1.add(email);
			    	    			
			    	    			JTextField phone = new JTextField();
			    	    			phone.setBounds(650, 340, 250, 25);
			    	    			phone.setBackground(Color.white);
			    	    			screen1.add(phone);
			    	    			phone.addKeyListener(new java.awt.event.KeyAdapter() {
			    	    				public void keyTyped(java.awt.event.KeyEvent evt) {
			    	    					phoneKeyTyped(evt);
			    	    				}
			    	    			});
			    	    	        
			    	    			JLabel Reg_no = new JLabel("Registration number :");
			    	    			Reg_no.setForeground(Color.LIGHT_GRAY);
			    	    			Reg_no.setBounds(500, 190, 250, 25);
			    	    			screen1.add(Reg_no);
			    	    			
			    	    			JLabel name = new JLabel("Name :");
			    	    			name.setForeground(Color.LIGHT_GRAY);
			    	    			name.setBounds(500, 220, 250, 25);
			    	    			screen1.add(name);
			    	    			
			    	    			JLabel program = new JLabel("Degree Program :");
			    	    			program.setForeground(Color.LIGHT_GRAY);
			    	    			program.setBounds(500, 250, 250, 25);
			    	    			screen1.add(program);
			    	    			
			    	    			JLabel CNIC = new JLabel("CNIC :");
			    	    			CNIC.setForeground(Color.LIGHT_GRAY);
			    	    			CNIC.setBounds(500, 280, 250, 25);
			    	    			screen1.add(CNIC);
			    	    	        
			    	    			JLabel email1 = new JLabel("e-mail :");
			    	    			email1.setForeground(Color.LIGHT_GRAY);
			    	    			email1.setBounds(500, 310, 100, 20);
			    	    			screen1.add(email1);
			    	    			
			    	    			JLabel phone1 = new JLabel("contact no :");
			    	    			phone1.setForeground(Color.LIGHT_GRAY);
			    	    			phone1.setBounds(500, 340, 100, 20);
			    	    			screen1.add(phone1);
			    	    			
			    	    			JLabel marid1 = new JLabel("Married");
			    	    			marid1.setForeground(Color.LIGHT_GRAY);
			    	    			marid1.setBounds(550, 370, 100, 20);
			    	    			screen1.add(marid1);
			    	    			
			    	    			JLabel unmarid1 = new JLabel("Single");
			    	    			unmarid1.setForeground(Color.LIGHT_GRAY);
			    	    			unmarid1.setBounds(550, 400, 100, 20);
			    	    			screen1.add(unmarid1);
			    	    			
			    	    			JRadioButton marid = new JRadioButton();
			    	    			marid.setBounds(500, 370, 20, 20);
			    	    			marid.setContentAreaFilled(false);
			    	    			screen1.add(marid);

			    	    			JRadioButton unmarid = new JRadioButton();
			    	    			unmarid.setBounds(500, 400, 20, 20);
			    	    			unmarid.setContentAreaFilled(false);
			    	    			screen1.add(unmarid);
			    	    			
			    	    			ButtonGroup group = new ButtonGroup();
			    	    			group.add(marid);
			    	    			group.add(unmarid);
			    	    			
			    	    			 JButton Enroll = new JButton("ENROLL");
			    	    			 Enroll.setBounds(730, 450, 200, 40);
			    	    			 Enroll.setBorder(new RoundedBorder(50));
			    	    			 Enroll.setContentAreaFilled(false);
			    	    			 Enroll.setFocusPainted(false);
			    	    			 Enroll.setForeground(Color.CYAN);
			    	    			 Enroll.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
				        		        screen1.add(Enroll);
			    	    			
			    	    			
				        		    JLabel logoname = new JLabel();
					    		    logoname = new JLabel("", iconname, JLabel.CENTER);
					    		    logoname.setBounds(0, 0, 300, 100);
					    		    screen1.add(logoname);
					    		        
			    	    			
			    	    			
			    	    			JLabel enrollbg1 = new JLabel();
			    	    			enrollbg1 = new JLabel("", enrollbg, JLabel.CENTER);
			    	    			enrollbg1.setBounds(450,70,500,450);
			    	    			screen1.add(enrollbg1);
			    	    			
			    	    			
			    	    			JLabel enroll = new JLabel();
			    	    			enroll = new JLabel("", enrollimg, JLabel.CENTER);
			    	    			enroll.setBounds(0,0,1000,600);
			    	    			screen1.add(enroll);
			    	    			
			    	    		        
			    	    		        back.addActionListener(new ActionListener() {
			    	    		            public void actionPerformed(ActionEvent e) {
			    	    		            	screen1.setVisible(false);
			    	    		            	screen2.setVisible(true);
			    	    		            	
			    	    		            }
			    	    		        });
			    	    		        screen1.setVisible(true); 
			    	    		       
			    	    				
			    	    				
			    	    		        Enroll.addActionListener(new ActionListener() {
						    	            public void actionPerformed(ActionEvent e) {
						    	            	
						    	            	    String registration_no_box = Registration_no.getText();
						    	    				String name_box = Name.getText();
						    	    				String degree_box = Program.getText();
						    	    				String CNIC_box = CNIC1.getText();
						    	    				String email_box = email.getText();
						    	    				String phone_box = phone.getText();
						    	    				String married_box=null;
						    	    				
						    	    				if (marid.isSelected()) {
						    	    					 married_box  = "marride";
						    	    				} else if (unmarid.isSelected()) {
						    	    				     married_box  = "single";
						    	    				} 
						    	            while(true) {
						    	            	
					    	    				if(registration_no_box !=null && name_box!=null && degree_box!=null && CNIC_box!=null && email_box!=null && phone_box!=null && married_box!=null) {
					    	    					try {
					    	    						String [] cheack=save_array();
					    	    						boolean condition=true;
					    	    						
					    	    						for(int i =0 ;i < cheack.length;i++) {
					    	    							if(registration_no_box.equalsIgnoreCase(cheack[i]) && cheack[i] != null) {
					    	    								condition=false;
					    	    							}
					    	    							
					    	    						}	
					    	    						
					    	    						
					    	    						if(condition) {
					    	    							File rec0 = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\Record.txt");
						    								FileWriter writt = new FileWriter(rec0, true);
						    								BufferedWriter BFW = new BufferedWriter(writt);
						    								BFW.write("\n"+registration_no_box.toUpperCase()+"\n"+name_box.toUpperCase()+"\n"+degree_box.toUpperCase()+"\n"+CNIC_box.toUpperCase()+"\n"+email_box+"\n"+phone_box.toUpperCase()+"\n"+married_box.toUpperCase());
						    							
						    								BFW.close();
						    								save_array();
						    								screen1.setVisible(false);
						    								screen2.setVisible(true);
						    								break;
					    	    						}else if(!condition) {
					    	    							screen1.setVisible(false);
				    	    								
				    	    								JFrame screen5 = new JFrame("OXFORD UNIVERSITY");
				    	    				            	screen5.setBounds(200,200,500, 300);
				    	    				    	        screen5.setResizable(false);
				    	    				    	        screen5.setIconImage(iconimg.getImage());
				    	    				    	        screen5.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
				    	    				    	        screen5.setLayout(null);
				    	    				    	        
				    	    				    	        JLabel title = new JLabel("\"STUDENT WITH SIMILLER REGISTRATION NO ", SwingConstants.CENTER);
				    	    				    	        title.setBounds(20, 50, 450, 50);
				    	    				    	        title.setForeground(Color.LIGHT_GRAY);
				    	    				    	        title.setFont(new Font("Times new romen", Font.BOLD, 15));
				    	    				    	        screen5.add(title);
				    	    				    	        
				    	    				    	        
				    	    				    	        JLabel title1 = new JLabel("ALREADY EXIST\"", SwingConstants.CENTER);
				    	    				    	        title1.setBounds(20, 70, 450, 50);
				    	    				    	        title1.setForeground(Color.LIGHT_GRAY);
				    	    				    	        title1.setFont(new Font("Times new romen", Font.BOLD, 15));
				    	    				    	        screen5.add(title1);
				    	    				    	        
				    	    				    	        JButton back = new JButton(" Go Back");
				    	    			    		        back.setBounds(20, 210, 200, 40);
				    	    			    		        back.setBorder(new RoundedBorder(50));
				    	    			    		        back.setContentAreaFilled(false);
				    	    			    		        back.setFocusPainted(false);
				    	    			    		        back.setForeground(Color.CYAN);
				    	    			    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
				    	    			    		        screen5.add(back);
				    	    			    		        
				    	    			    		        JLabel invalid = new JLabel();
				    	    			    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
				    	    			    		        invalid.setBounds(0, 0, 500, 300);
				    	    			    		        screen5.add(invalid);
				    	    			    		        
				    	    				    	        screen5.setVisible(true);
				    	    				    	        
				    	    			    		        back.addActionListener(new ActionListener() {
				    	    			    		            public void actionPerformed(ActionEvent e) {
				    	    			    		            	screen5.setVisible(false);
				    	    			    		            	screen1.setVisible(true);
				    	    			    		            	
				    	    			    		            }
				    	    			    		        });
				    	    			    		        break;
					    	    						}
					    	    						

					    							} catch (Exception n) {
					    							}
					    	    				}else {
					    	    					toast t = new toast("Fill all the feilds", 400, 400);
					    	    			        t.showtoast(); 
					    	    			        break;
					    	    					
					    	    				}}					    	    				
						    	            }
						    	        });	
						    	            	
						    	        
			    	    		        
			    	    		        
			    	    		        
			    	            }
			    	        });
			    	        
			    	        
			    	        b11.addActionListener(new ActionListener() {
			    	            public void actionPerformed(ActionEvent e) {
			    	            	screen2.setVisible(false);
			    	            	
			    	            	JFrame screen6 = new JFrame("OXFORD UNIVERSITY");
			    	            	screen6.setSize(1000, 600);
			    	    	        screen6.setResizable(false);
			    	    	        screen6.setIconImage(iconimg.getImage());
			    	    	        screen6.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	    	        screen6.setLayout(null);
			    	    	        
			    	    	        JButton back = new JButton(" Go Back");
				    		        back.setBounds(20, 510, 200, 40);
				    		        back.setBorder(new RoundedBorder(50));
				    		        back.setContentAreaFilled(false);
				    		        back.setFocusPainted(false);
				    		        back.setForeground(Color.WHITE);
				    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
			        		        screen6.add(back);
			        		        
			        		        JLabel Reg_no = new JLabel("Enter Registration number :");
			    	    			Reg_no.setForeground(Color.WHITE);
			    	    			Reg_no.setBounds(470, 80, 250, 25);
			    	    			screen6.add(Reg_no);
			        		        
			        		        JTextField Registration_no = new JTextField();
			        		        Registration_no.setForeground(Color.DARK_GRAY);
			    	    	        Registration_no.setBounds(470, 110, 250, 35);
			    	    	        Registration_no.setBackground(Color.white);
			    	    			screen6.add(Registration_no);
			    	    			
			    	    			JTextField Name = new JTextField();
			    	    	        Name.setBounds(650, 220, 250, 25);
			    	    	        Name.setBackground(Color.white);
			    	    			screen6.add(Name);
			    	    			
			    	    			JTextField Program = new JTextField();
			    	    	        Program.setBounds(650, 250, 250, 25);
			    	    	        Program.setBackground(Color.white);
			    	    			screen6.add(Program);
			    	    			
			    	    			JTextField CNIC1 = new JTextField();
			    	    			CNIC1.setBounds(650, 280, 250, 25);
			    	    			CNIC1.setBackground(Color.white);
			    	    			screen6.add(CNIC1);
			    	    			
			    	    			JTextField email = new JTextField();
			    	    			email.setBounds(650, 310, 250, 25);
			    	    			email.setBackground(Color.white);
			    	    			screen6.add(email);
			    	    			
			    	    			JTextField phone = new JTextField();
			    	    			phone.setBounds(650, 340, 250, 25);
			    	    			phone.setBackground(Color.white);
			    	    			screen6.add(phone);
			    	    			
			    	    			JTextField Mstatus = new JTextField();
			    	    			Mstatus.setBounds(650, 370, 250, 25);
			    	    			Mstatus.setBackground(Color.white);
			    	    			screen6.add(Mstatus);
			    	    	        
			    	    			
			    	    			
			    	    			JLabel name = new JLabel("Name :");
			    	    			name.setForeground(Color.LIGHT_GRAY);
			    	    			name.setBounds(500, 220, 250, 25);
			    	    			screen6.add(name);
			    	    			
			    	    			JLabel program = new JLabel("Degree Program :");
			    	    			program.setForeground(Color.LIGHT_GRAY);
			    	    			program.setBounds(500, 250, 250, 25);
			    	    			screen6.add(program);
			    	    			
			    	    			JLabel CNIC = new JLabel("CNIC :");
			    	    			CNIC.setForeground(Color.LIGHT_GRAY);
			    	    			CNIC.setBounds(500, 280, 250, 25);
			    	    			screen6.add(CNIC);
			    	    	        
			    	    			JLabel email1 = new JLabel("e-mail :");
			    	    			email1.setForeground(Color.LIGHT_GRAY);
			    	    			email1.setBounds(500, 310, 100, 20);
			    	    			screen6.add(email1);
			    	    			
			    	    			JLabel phone1 = new JLabel("contact no :");
			    	    			phone1.setForeground(Color.LIGHT_GRAY);
			    	    			phone1.setBounds(500, 340, 100, 20);
			    	    			screen6.add(phone1);
			    	    			
			    	    			JLabel marid1 = new JLabel("Marrital status :");
			    	    			marid1.setForeground(Color.LIGHT_GRAY);
			    	    			marid1.setBounds(500, 370, 100, 20);
			    	    			screen6.add(marid1);
			    	    			
			    	    			
			    	    			 JButton update = new JButton("UPDATE");
    	    		            	 update.setBounds(730, 450, 200, 40);
    	    		            	 update.setBorder(new RoundedBorder(50));
    	    		            	 update.setContentAreaFilled(false);
    	    		            	 update.setFocusPainted(false);
    	    		            	 update.setForeground(Color.CYAN);
    	    		            	 update.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
				        		        screen6.add(update);
			    	    			
			    	    			 JButton search = new JButton("SEARCH");
			    	    			 search.setBounds(730, 110, 190, 40);
			    	    			 search.setBorder(new RoundedBorder(50));
			    	    			 search.setContentAreaFilled(false);
			    	    			 search.setFocusPainted(false);
			    	    			 search.setForeground(Color.CYAN);
			    	    			 search.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
				        		        screen6.add(search);
			    	    			
			    	    			
				        		    JLabel logoname = new JLabel();
					    		    logoname = new JLabel("", iconname, JLabel.CENTER);
					    		    logoname.setBounds(0, 0, 300, 100);
					    		    screen6.add(logoname);
					    		        
			    	    			JLabel enrollbg1 = new JLabel();
			    	    			enrollbg1 = new JLabel("", enrollbg, JLabel.CENTER);
			    	    			enrollbg1.setBounds(450,70,500,450);
			    	    			screen6.add(enrollbg1);
			    	    			
			    	            	
			    	            	screen6.setVisible(true);
			    	            	
			    	            	JLabel bg = new JLabel();
			    	    	        bg = new JLabel("", updateimg, JLabel.CENTER);
			    	    	        bg.setBounds(0, 0, 1000, 600);
			    	    	        screen6.add(bg);
			    	    	        
			    	    	        search.addActionListener(new ActionListener() {
		    	    		            public void actionPerformed(ActionEvent e) {
		    	    		            	
		    	    		            	
		    	    		            	
		    	    		            	
		    	    		            	String line = null;
		    	    		            	line= Registration_no.getText();
		    	    		            	String data [] =new String [6];
		    	    		            	boolean found=false;
		    	    		            	String [] A= save_array();
		    	    		            	for(int i=0;i<A.length;i++) {
		    	    		            		if (line.equalsIgnoreCase(A[i]) && line !=null && line !="") {
		    	    		            			data[0]=A[i+1];
		    	    		            			data[1]=A[i+2];
		    	    		            			data[2]=A[i+3];
		    	    		            			data[3]=A[i+4];
		    	    		            			data[4]=A[i+5];
		    	    		            			data[5]=A[i+6];
		    	    		            			Name.setText(data[0]);
			    	    		            		Program.setText(data[1]);
			    	    		            		CNIC1.setText(data[2]);
			    	    		            		email.setText(data[3]);
			    	    		            		phone.setText(data[4]);
			    	    		            		Mstatus.setText(data[5]);
			    	    		            		found=true;
			    	    		            		
			    	    		            		 
		    	    		            			break;
		    	    		            		}
		    	    		            		
		    	    		            	}
		    	    		            	if(!found) {
		    	    		            		screen6.setVisible(false);
	    	    								
	    	    								JFrame screen5 = new JFrame("OXFORD UNIVERSITY");
	    	    				            	screen5.setBounds(200,200,500, 300);
	    	    				    	        screen5.setResizable(false);
	    	    				    	        screen5.setIconImage(iconimg.getImage());
	    	    				    	        screen5.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	    	    				    	        screen5.setLayout(null);
	    	    				    	        
	    	    				    	        JLabel title = new JLabel("\"INVALID REGISTRATION NO ", SwingConstants.CENTER);
	    	    				    	        title.setBounds(20, 50, 450, 50);
	    	    				    	        title.setForeground(Color.LIGHT_GRAY);
	    	    				    	        title.setFont(new Font("Times new romen", Font.BOLD, 15));
	    	    				    	        screen5.add(title);
	    	    				    	        
	    	    				    	        
	    	    				    	        JLabel title1 = new JLabel("OR THIS IS NOT A REGISTERED ROLL NUMBER\"", SwingConstants.CENTER);
	    	    				    	        title1.setBounds(20, 70, 450, 50);
	    	    				    	        title1.setForeground(Color.LIGHT_GRAY);
	    	    				    	        title1.setFont(new Font("Times new romen", Font.BOLD, 15));
	    	    				    	        screen5.add(title1);
	    	    				    	        
	    	    				    	        JButton back = new JButton(" Go Back");
	    	    			    		        back.setBounds(20, 210, 200, 40);
	    	    			    		        back.setBorder(new RoundedBorder(50));
	    	    			    		        back.setContentAreaFilled(false);
	    	    			    		        back.setFocusPainted(false);
	    	    			    		        back.setForeground(Color.CYAN);
	    	    			    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
	    	    			    		        screen5.add(back);
	    	    			    		        
	    	    			    		        JLabel invalid = new JLabel();
	    	    			    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
	    	    			    		        invalid.setBounds(0, 0, 500, 300);
	    	    			    		        screen5.add(invalid);
	    	    			    		        
	    	    				    	        screen5.setVisible(true);
	    	    				    	        
	    	    			    		        back.addActionListener(new ActionListener() {
	    	    			    		            public void actionPerformed(ActionEvent e) {
	    	    			    		            	screen5.setVisible(false);
	    	    			    		            	screen6.setVisible(true);
	    	    			    		            	
	    	    			    		            }
	    	    			    		        });
		    	    		            		
		    	    		            		
		    	    		            		
		    	    		            	}
		    	    		            }
		    	    		        });
			    	    	        
			    	    	        
			    	    	        update.addActionListener(new ActionListener() {
					    	            public void actionPerformed(ActionEvent e) {
					    	            	
					    	            	    String registration_no_box = Registration_no.getText();
					    	    				String name_box = Name.getText();
					    	    				String degree_box = Program.getText();
					    	    				String CNIC_box = CNIC1.getText();
					    	    				String email_box = email.getText();
					    	    				String phone_box = phone.getText();
					    	    				String married_box=Mstatus.getText();
					    	    				
					    	            while(true) {
					    	            	
				    	    				if(registration_no_box !=null && name_box!=null && degree_box!=null && CNIC_box!=null && email_box!=null && phone_box!=null && married_box!=null) {
				    	    					try {
				    	    						
				    	    						String [] cheack=save_array();
				    	    						boolean condition=false;
				    	    						
				    	    						for(int i =0 ;i < cheack.length;i++) {
				    	    							if(registration_no_box.equalsIgnoreCase(cheack[i]) && cheack[i] != null) {
				    	    								cheack[i+1]=name_box.toUpperCase();
				    	    								cheack[i+2]=degree_box.toUpperCase();
				    	    								cheack[i+3]=CNIC_box.toUpperCase();
				    	    								cheack[i+4]=email_box;
				    	    								cheack[i+5]=phone_box.toUpperCase();
				    	    								cheack[i+6]=married_box.toUpperCase();
				    	    								condition = true;
				    	    							}
				    	    							
				    	    						}	
				    	    						
				    	    						
				    	    						if(condition) {
				    	    							File rec0 = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\Record.txt");
					    								FileWriter writt = new FileWriter(rec0);
					    								BufferedWriter BFW = new BufferedWriter(writt);
					    								for(int i =0 ;i < cheack.length;i++) {
					    									if (cheack[i]!=null) {
					    									BFW.write(cheack[i]+"\n");
					    									}
					    								}
					    								
					    							
					    								BFW.close();
					    								save_array();
					    								screen6.setVisible(false);
					    								screen2.setVisible(true);
					    								break;
				    	    						}else if(!condition) {
				    	    							screen6.setVisible(false);
			    	    								
			    	    								JFrame screen5 = new JFrame("OXFORD UNIVERSITY");
			    	    				            	screen5.setBounds(200,200,500, 300);
			    	    				    	        screen5.setResizable(false);
			    	    				    	        screen5.setIconImage(iconimg.getImage());
			    	    				    	        screen5.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	    				    	        screen5.setLayout(null);
			    	    				    	        
			    	    				    	        JLabel title = new JLabel("\"First enter Registration number", SwingConstants.CENTER);
			    	    				    	        title.setBounds(20, 50, 450, 50);
			    	    				    	        title.setForeground(Color.LIGHT_GRAY);
			    	    				    	        title.setFont(new Font("Times new romen", Font.BOLD, 15));
			    	    				    	        screen5.add(title);
			    	    				    	        
			    	    				    	        
			    	    				    	        JLabel title1 = new JLabel("and search for Student Data\"", SwingConstants.CENTER);
			    	    				    	        title1.setBounds(20, 70, 450, 50);
			    	    				    	        title1.setForeground(Color.LIGHT_GRAY);
			    	    				    	        title1.setFont(new Font("Times new romen", Font.BOLD, 15));
			    	    				    	        screen5.add(title1);
			    	    				    	        
			    	    				    	        JButton back = new JButton(" Go Back");
			    	    			    		        back.setBounds(20, 210, 200, 40);
			    	    			    		        back.setBorder(new RoundedBorder(50));
			    	    			    		        back.setContentAreaFilled(false);
			    	    			    		        back.setFocusPainted(false);
			    	    			    		        back.setForeground(Color.CYAN);
			    	    			    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
			    	    			    		        screen5.add(back);
			    	    			    		        
			    	    			    		        JLabel invalid = new JLabel();
			    	    			    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
			    	    			    		        invalid.setBounds(0, 0, 500, 300);
			    	    			    		        screen5.add(invalid);
			    	    			    		        
			    	    				    	        screen5.setVisible(true);
			    	    				    	        
			    	    			    		        back.addActionListener(new ActionListener() {
			    	    			    		            public void actionPerformed(ActionEvent e) {
			    	    			    		            	screen5.setVisible(false);
			    	    			    		            	screen6.setVisible(true);
			    	    			    		            	
			    	    			    		            }
			    	    			    		        });
			    	    			    		        break;
				    	    						}
				    	    						

				    							} catch (Exception n) {
				    							}
				    	    				}else {
				    	    					toast t = new toast("Fill all the feilds", 400, 400);
				    	    			        t.showtoast(); 
				    	    			        break;
				    	    					
				    	    				}}					    	    				
					    	            }
					    	        });	
			    	    	        
			    	    	        
			    	            	back.addActionListener(new ActionListener() {
		    	    		            public void actionPerformed(ActionEvent e) {
		    	    		            	screen6.setVisible(false);
		    	    		            	screen2.setVisible(true);
		    	    		            	
		    	    		            }
		    	    		        });
			    	            }
		    		        });
			    	        
			    	        
			    	        
			    	        b111.addActionListener(new ActionListener() {
			    	            public void actionPerformed(ActionEvent e) {
			    	            	screen2.setVisible(false);
			    	            	
			    	            	JFrame screen7 = new JFrame("OXFORD UNIVERSITY");
			    	            	screen7.setSize(1000, 600);
			    	    	        screen7.setResizable(false);
			    	    	        screen7.setIconImage(iconimg.getImage());
			    	    	        screen7.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	    	        screen7.setLayout(null);
			    	    	        
			    	    	        JButton back = new JButton(" Go Back");
				    		        back.setBounds(20, 510, 200, 40);
				    		        back.setBorder(new RoundedBorder(50));
				    		        back.setContentAreaFilled(false);
				    		        back.setFocusPainted(false);
				    		        back.setForeground(Color.BLACK);
				    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
			        		        screen7.add(back);
			    	            	
			        		        
			        		        JLabel Reg_no = new JLabel("Enter Registration number :");
			    	    			Reg_no.setForeground(Color.WHITE);
			    	    			Reg_no.setBounds(470, 80, 250, 25);
			    	    			screen7.add(Reg_no);
			        		        
			        		        JTextField Registration_no = new JTextField();
			        		        Registration_no.setForeground(Color.DARK_GRAY);
			    	    	        Registration_no.setBounds(470, 110, 250, 35);
			    	    	        Registration_no.setBackground(Color.white);
			    	    			screen7.add(Registration_no);
			    	    			
			    	    			JTextField Name = new JTextField();
			    	    	        Name.setBounds(650, 220, 250, 25);
			    	    	        Name.setBackground(Color.white);
			    	    			screen7.add(Name);
			    	    			
			    	    			JTextField Program = new JTextField();
			    	    	        Program.setBounds(650, 250, 250, 25);
			    	    	        Program.setBackground(Color.white);
			    	    			screen7.add(Program);
			    	    			
			    	    			JTextField CNIC1 = new JTextField();
			    	    			CNIC1.setBounds(650, 280, 250, 25);
			    	    			CNIC1.setBackground(Color.white);
			    	    			screen7.add(CNIC1);
			    	    			
			    	    			JTextField email = new JTextField();
			    	    			email.setBounds(650, 310, 250, 25);
			    	    			email.setBackground(Color.white);
			    	    			screen7.add(email);
			    	    			
			    	    			JTextField phone = new JTextField();
			    	    			phone.setBounds(650, 340, 250, 25);
			    	    			phone.setBackground(Color.white);
			    	    			screen7.add(phone);
			    	    			
			    	    			JTextField Mstatus = new JTextField();
			    	    			Mstatus.setBounds(650, 370, 250, 25);
			    	    			Mstatus.setBackground(Color.white);
			    	    			screen7.add(Mstatus);
			    	    	        
			    	    			
			    	    			
			    	    			JLabel name = new JLabel("Name :");
			    	    			name.setForeground(Color.LIGHT_GRAY);
			    	    			name.setBounds(500, 220, 250, 25);
			    	    			screen7.add(name);
			    	    			
			    	    			JLabel program = new JLabel("Degree Program :");
			    	    			program.setForeground(Color.LIGHT_GRAY);
			    	    			program.setBounds(500, 250, 250, 25);
			    	    			screen7.add(program);
			    	    			
			    	    			JLabel CNIC = new JLabel("CNIC :");
			    	    			CNIC.setForeground(Color.LIGHT_GRAY);
			    	    			CNIC.setBounds(500, 280, 250, 25);
			    	    			screen7.add(CNIC);
			    	    	        
			    	    			JLabel email1 = new JLabel("e-mail :");
			    	    			email1.setForeground(Color.LIGHT_GRAY);
			    	    			email1.setBounds(500, 310, 100, 20);
			    	    			screen7.add(email1);
			    	    			
			    	    			JLabel phone1 = new JLabel("contact no :");
			    	    			phone1.setForeground(Color.LIGHT_GRAY);
			    	    			phone1.setBounds(500, 340, 100, 20);
			    	    			screen7.add(phone1);
			    	    			
			    	    			JLabel marid1 = new JLabel("Marrital status :");
			    	    			marid1.setForeground(Color.LIGHT_GRAY);
			    	    			marid1.setBounds(500, 370, 100, 20);
			    	    			screen7.add(marid1);
			    	    			
			    	    			
			    	    			
			    	    			
			    	    			 JButton search = new JButton("SEARCH");
			    	    			 search.setBounds(730, 110, 190, 40);
			    	    			 search.setBorder(new RoundedBorder(50));
			    	    			 search.setContentAreaFilled(false);
			    	    			 search.setFocusPainted(false);
			    	    			 search.setForeground(Color.CYAN);
			    	    			 search.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
				        		        screen7.add(search);
			    	    			
			    	    			
				        		    JLabel logoname = new JLabel();
					    		    logoname = new JLabel("", iconname, JLabel.CENTER);
					    		    logoname.setBounds(0, 0, 300, 100);
					    		    screen7.add(logoname);
					    		        
			    	    			JLabel enrollbg1 = new JLabel();
			    	    			enrollbg1 = new JLabel("", enrollbg, JLabel.CENTER);
			    	    			enrollbg1.setBounds(450,70,500,450);
			    	    			screen7.add(enrollbg1);
			        		        
			        		        
			    	            	screen7.setVisible(true);
			    	            	
			    	            	JLabel bg = new JLabel();
			    	    	        bg = new JLabel("", searchimg, JLabel.CENTER);
			    	    	        bg.setBounds(0, 0, 1000, 600);
			    	    	        screen7.add(bg);
			    	    	        
			    	    	        search.addActionListener(new ActionListener() {
		    	    		            public void actionPerformed(ActionEvent e) {
		    	    		            	String line= Registration_no.getText();
		    	    		            	String data [] =new String [6];
		    	    		            	boolean found=false;
		    	    		            	String [] A= save_array();
		    	    		            	for(int i=0;i<A.length;i++) {
		    	    		            		if (line.equalsIgnoreCase(A[i]) && line !=null && line !="") {
		    	    		            			data[0]=A[i+1];
		    	    		            			data[1]=A[i+2];
		    	    		            			data[2]=A[i+3];
		    	    		            			data[3]=A[i+4];
		    	    		            			data[4]=A[i+5];
		    	    		            			data[5]=A[i+6];
		    	    		            			Name.setText(data[0]);
			    	    		            		Program.setText(data[1]);
			    	    		            		CNIC1.setText(data[2]);
			    	    		            		email.setText(data[3]);
			    	    		            		phone.setText(data[4]);
			    	    		            		Mstatus.setText(data[5]);
			    	    		            		found=true;
		    	    		            			break;
		    	    		            		}
		    	    		            		
		    	    		            	}
		    	    		            	if(!found) {
		    	    		            		screen7.setVisible(false);
	    	    								
	    	    								JFrame screen5 = new JFrame("OXFORD UNIVERSITY");
	    	    				            	screen5.setBounds(200,200,500, 300);
	    	    				    	        screen5.setResizable(false);
	    	    				    	        screen5.setIconImage(iconimg.getImage());
	    	    				    	        screen5.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	    	    				    	        screen5.setLayout(null);
	    	    				    	        
	    	    				    	        JLabel title = new JLabel("\"INVALID REGISTRATION NO ", SwingConstants.CENTER);
	    	    				    	        title.setBounds(20, 50, 450, 50);
	    	    				    	        title.setForeground(Color.LIGHT_GRAY);
	    	    				    	        title.setFont(new Font("Times new romen", Font.BOLD, 15));
	    	    				    	        screen5.add(title);
	    	    				    	        
	    	    				    	        
	    	    				    	        JLabel title1 = new JLabel("OR THIS IS NOT A REGISTERED ROLL NUMBER\"", SwingConstants.CENTER);
	    	    				    	        title1.setBounds(20, 70, 450, 50);
	    	    				    	        title1.setForeground(Color.LIGHT_GRAY);
	    	    				    	        title1.setFont(new Font("Times new romen", Font.BOLD, 15));
	    	    				    	        screen5.add(title1);
	    	    				    	        
	    	    				    	        JButton back = new JButton(" Go Back");
	    	    			    		        back.setBounds(20, 210, 200, 40);
	    	    			    		        back.setBorder(new RoundedBorder(50));
	    	    			    		        back.setContentAreaFilled(false);
	    	    			    		        back.setFocusPainted(false);
	    	    			    		        back.setForeground(Color.CYAN);
	    	    			    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
	    	    			    		        screen5.add(back);
	    	    			    		        
	    	    			    		        JLabel invalid = new JLabel();
	    	    			    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
	    	    			    		        invalid.setBounds(0, 0, 500, 300);
	    	    			    		        screen5.add(invalid);
	    	    			    		        
	    	    				    	        screen5.setVisible(true);
	    	    				    	        
	    	    			    		        back.addActionListener(new ActionListener() {
	    	    			    		            public void actionPerformed(ActionEvent e) {
	    	    			    		            	screen5.setVisible(false);
	    	    			    		            	screen7.setVisible(true);
	    	    			    		            	
	    	    			    		            }
	    	    			    		        });
		    	    		            		
		    	    		            		
		    	    		            		
		    	    		            	}
		    	    		            }
		    	    		        });
			    	    	        
			    	    	        
			    	            	back.addActionListener(new ActionListener() {
		    	    		            public void actionPerformed(ActionEvent e) {
		    	    		            	screen7.setVisible(false);
		    	    		            	screen2.setVisible(true);
		    	    		            	
		    	    		            }
		    	    		        });
			    	            }
		    		        });
			    	            	
			    	        JButton back = new JButton(" Go Back");
		    		        back.setBounds(10, 500, 200, 40);
		    		        back.setBorder(new RoundedBorder(50));
		    		        back.setContentAreaFilled(false);
		    		        back.setFocusPainted(false);
		    		        back.setForeground(Color.CYAN);
		    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
		    		        screen2.add(back);
		    	        
		    		        JLabel welcome = new JLabel();
		    		        welcome = new JLabel("", welcomeimg, JLabel.CENTER);
		    		        welcome.setBounds(0, 0, 1000, 600);
		    		        screen2.add(welcome);
		    		        
		    		        screen2.setVisible(true);
		    		        
		    		        back.addActionListener(new ActionListener() {
		    		            public void actionPerformed(ActionEvent e) {
		    		            	screen2.setVisible(false);
		    		            	screen.setVisible(true);
		    		            	
		    		            }
		    		        });
		            	}
		            	else {
		            		
		            		screen.setVisible(false);
		            		
		            		JFrame screen4 = new JFrame("OXFORD UNIVERSITY");
			            	screen4.setBounds(200,200,500, 300);
			    	        screen4.setResizable(false);
			    	        screen4.setIconImage(iconimg.getImage());
			    	        screen4.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	        screen4.setLayout(null);
			    	        
			    	        JLabel title = new JLabel("\"INVALID ADMIN INFO!\"", SwingConstants.CENTER);
			    	        title.setBounds(20, 70, 450, 50);
			    	        title.setForeground(Color.LIGHT_GRAY);
			    	        title.setFont(new Font("Times new romen", Font.BOLD, 25));
			    	        screen4.add(title);
			    	        
			    	        JButton back = new JButton(" Go Back");
		    		        back.setBounds(20, 210, 200, 40);
		    		        back.setBorder(new RoundedBorder(50));
		    		        back.setContentAreaFilled(false);
		    		        back.setFocusPainted(false);
		    		        back.setForeground(Color.CYAN);
		    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
		    		        screen4.add(back);
		    		        
		    		        JLabel invalid = new JLabel();
		    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
		    		        invalid.setBounds(0, 0, 500, 300);
		    		        screen4.add(invalid);
		    		        
			    	        screen4.setVisible(true);
			    	        
		    		        back.addActionListener(new ActionListener() {
		    		            public void actionPerformed(ActionEvent e) {
		    		            	screen4.setVisible(false);
		    		            	screen.setVisible(true);
		    		            	
		    		            }
		    		        });
	            	}
		            	BFR.close();
					} catch (Exception E) {
						E.printStackTrace();
					}
	            	
	            }
	        });
	        
	        b3.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	try {
						File rec0 = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\login.txt");
						
						
						FileReader read = new FileReader(rec0);
						BufferedReader BFR = new BufferedReader(read);
						
						String line1 = BFR.readLine();
						String line2 = BFR.readLine();
						
						
						String emailch1 = email.getText();
		            	String passwordch1 = password.getText();
		            	
		            	
		            	if (line1.equals(emailch1) && line2.equals(passwordch1) ) {
		            		screen.setVisible(false);
		            		JFrame screen3 = new JFrame("OXFORD UNIVERSITY");
			            	screen3.setSize(900, 600);
			    	        screen3.setResizable(false);
			    	        screen3.setIconImage(iconimg.getImage());
			    	        screen3.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	        screen3.setLayout(null);
			    	        
			    	        
			    	        JTextField email1 = new JTextField();
			    			email1.setBounds(275, 200, 355, 50);
			    			email1.setOpaque(false);
			    			email1.setForeground(Color.LIGHT_GRAY);
			    			screen3.add(email1);
			    			
			    			JTextField password1 = new JTextField();
			    			password1.setBounds(275, 300, 355, 50);
			    			password1.setOpaque(false);
			    			password1.setForeground(Color.LIGHT_GRAY);
			    			screen3.add(password1);
			    	       
			    			JButton change = new JButton("CHANGE");
			    	        change.setBounds(540, 360, 110, 30);
			    	        change.setBorderPainted(false);
			    	        change.setContentAreaFilled(false);
			    	        change.setFocusPainted(false);
			    	        change.setForeground(Color.CYAN);
			    	        change.setFont(new Font("Bahnschrift Light SemiCondensed", Font.BOLD, 15));
			    	        screen3.add(change);
			    	        
			    	        
			    	        JLabel logoname = new JLabel();
			    		    logoname = new JLabel("", iconname, JLabel.CENTER);
			    		    logoname.setBounds(0, 10, 300, 100);
			    		    screen3.add(logoname);
			    	        
			    	        
			    	        JLabel loginchange = new JLabel();
			    	        loginchange = new JLabel("", loginchangeimg, JLabel.CENTER);
			    	        loginchange.setBounds(0, 0, 900, 600);
			    	        screen3.add(loginchange);
			    	        
			    	        screen3.setVisible(true);
			    	        change.addActionListener(new ActionListener() {
			    	            public void actionPerformed(ActionEvent e) {
			    	            try {	
			    	            	File rec0 = new File("H:\\hassan UNIVERSITY\\2nd semister\\programming fundamintals\\final project\\FP\\Hassan\\login.txt");
			    	            	FileWriter writt = new FileWriter(rec0);
									BufferedWriter BFW = new BufferedWriter(writt);
									
					            		String emailch1 = email1.getText();
						            	String passwordch1 = password1.getText();
						            	
						            	BFW.write(emailch1+"\n"+passwordch1);
							            BFW.close();
							            screen3.setVisible(false);
							            screen.setVisible(true);
			    	            }catch(Exception E) {
			    	            	
			    	            }
			    	            	}
			    	            });
			    	        
		            	}
		            	else {
		            		
		            		screen.setVisible(false);
		            		JFrame screen4 = new JFrame("OXFORD UNIVERSITY");
			            	screen4.setBounds(200,200,500, 300);
			    	        screen4.setResizable(false);
			    	        screen4.setIconImage(iconimg.getImage());
			    	        screen4.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			    	        screen4.setLayout(null);
			    	        
			    	        JLabel title = new JLabel("\"INVALID ADMIN INFO!\"", SwingConstants.CENTER);
			    	        title.setBounds(20, 70, 450, 50);
			    	        title.setForeground(Color.LIGHT_GRAY);
			    	        title.setFont(new Font("Times new romen", Font.BOLD, 25));
			    	        screen4.add(title);
			    	        
			    	        JButton back = new JButton(" Go Back");
		    		        back.setBounds(20, 210, 200, 40);
		    		        back.setBorder(new RoundedBorder(50));
		    		        back.setContentAreaFilled(false);
		    		        back.setFocusPainted(false);
		    		        back.setForeground(Color.CYAN);
		    		        back.setFont(new Font("Bahnschrift Light SemiCondensed", Font.PLAIN , 15));
		    		        screen4.add(back);
		    		        
		    		        JLabel invalid = new JLabel();
		    		        invalid = new JLabel("", invalidimg, JLabel.CENTER);
		    		        invalid.setBounds(0, 0, 500, 300);
		    		        screen4.add(invalid);
		    		        
			    	        screen4.setVisible(true);
			    	        
		    		        back.addActionListener(new ActionListener() {
		    		            public void actionPerformed(ActionEvent e) {
		    		            	screen4.setVisible(false);
		    		            	screen.setVisible(true);
		    		            	
		    		            }
		    		        });
		            	}
		            	BFR.close();
					} catch (Exception E) {
						E.printStackTrace();
					}
	            }
	        });

	    }
}
